FITWARRIOR ANDROID WRAPPER — v1
===============================

This project wraps the current FitWarrior HTML app in a small Android WebView app.
The HTML is bundled inside the APK, so the app can open offline. It does not need
internet permission. Progress is stored in the app's local WebView storage and is
not synced between devices.

PHONE-FRIENDLY BUILD OPTION (GitHub Actions)
--------------------------------------------
1. Extract this ZIP on your phone.
2. Create a new repository on GitHub in your browser.
3. Upload the extracted PROJECT CONTENTS to the repository (not the ZIP file itself),
   preserving the folder structure, including the .github/workflows/build-apk.yml file.
4. Open the repository's Actions tab and select "Build FitWarrior APK".
   If the workflow is not shown, open Actions and enable workflows, then push a change.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find Artifacts, and download
   FitWarrior-debug-apk. Extract it to get app-debug.apk.
7. Tap the APK on your Android phone to install. Android may ask you to permit
   installation from that browser or file manager. Only install APKs you built or
   trust. Share the APK with friends who want to test it.

ALTERNATIVE
-----------
Import this project into an Android IDE that supports Gradle Android projects and
Java 17, then run the app or build the debug APK.

NOTES
-----
- This is a debug/test APK, not a Play Store release.
- A release distributed widely should be release-signed and tested.
- Application ID: com.fitwarrior.app
- Min Android version: Android 6.0 (API 23)
- The HTML file is app/src/main/assets/index.html.
- To update the app, replace that file with a revised FitWarrior HTML prototype
  before building again.
